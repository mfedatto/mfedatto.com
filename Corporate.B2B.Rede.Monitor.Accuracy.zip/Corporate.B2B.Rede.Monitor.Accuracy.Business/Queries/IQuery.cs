﻿namespace Corporate.B2B.Rede.Monitor.Accuracy.Business.Queries
{
    public interface IQuery<in TQueryRequest, out TQueryResponse>
        where TQueryRequest : class
        where TQueryResponse : class
    {
        TQueryResponse Execute(TQueryRequest queryRequest);
    }
}
