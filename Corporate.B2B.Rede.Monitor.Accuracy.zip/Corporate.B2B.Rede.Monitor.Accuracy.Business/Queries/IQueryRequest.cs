﻿namespace Corporate.B2B.Rede.Monitor.Accuracy.Business.Queries
{
    public interface IQueryRequest { }
}
