﻿namespace Corporate.B2B.Rede.Monitor.Accuracy.Business.Queries
{
    public abstract class AbstractQuery<TRepositoryInterface, TValidator, TQueryRequest, TQueryResponse> : IQuery<TQueryRequest, TQueryResponse>
        where TRepositoryInterface : class
        where TQueryRequest : class
        where TQueryResponse : class
    {
        protected readonly TRepositoryInterface _repository;
        protected readonly TValidator _validator;

        protected AbstractQuery(TRepositoryInterface repository, TValidator validator)
        {
            _repository = repository;
            _validator = validator;
        }

        public abstract TQueryResponse Execute(TQueryRequest queryRequest);
    }
}
