﻿namespace Corporate.B2B.Rede.Monitor.Accuracy.Business.Queries.GetAllAdvisorCodeList
{
    public class GetAllAdvisorCodeListResponse : IQueryResponse
    {
        public string[] AdvisorCodeList { get; private set; }
    }
}
