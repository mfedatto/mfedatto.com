﻿using Corporate.B2B.Rede.Monitor.Accuracy.Domain.Advisor;
using System;

namespace Corporate.B2B.Rede.Monitor.Accuracy.Business.Queries.GetAllAdvisorCodeList
{
    public class GetAllAdvisorCodeListQuery : AbstractQuery<IAdvisorRepository, AdvisorCodeListGetAllValidator, GetAllAdvisorCodeListRequest, GetAllAdvisorCodeListResponse>
    {
        public GetAllAdvisorCodeListQuery(IAdvisorRepository repository, AdvisorCodeListGetAllValidator validator)
            : base(repository, validator) { }

        public override GetAllAdvisorCodeListResponse Execute(GetAllAdvisorCodeListRequest queryRequest)
        {
            GetAllAdvisorCodeListResponse response = null;

            if (!_validator.IsRequestValid(queryRequest))
                throw new ArgumentException("Bad request");

            if (!_validator.IsResponseValid(response))
                throw new ArgumentException("Bad response");

            return response;
        }
    }
}
