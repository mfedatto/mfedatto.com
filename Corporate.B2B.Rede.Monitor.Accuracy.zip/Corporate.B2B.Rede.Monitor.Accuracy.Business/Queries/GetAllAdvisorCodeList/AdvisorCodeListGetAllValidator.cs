﻿namespace Corporate.B2B.Rede.Monitor.Accuracy.Business.Queries.GetAllAdvisorCodeList
{
    public class AdvisorCodeListGetAllValidator
    {
        public bool IsRequestValid(GetAllAdvisorCodeListRequest request)
        {
            return true;
        }

        public bool IsResponseValid(GetAllAdvisorCodeListResponse response)
        {
            return (response != null && response.AdvisorCodeList != null);
        }
    }
}
