﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Corporate.B2B.Rede.Monitor.Accuracy.Business.Queries.GetAllAdvisorCodeList
{
    public class GetAllAdvisorCodeListRequest : IQueryRequest
    {
    }
}
