﻿using Corporate.B2B.Rede.Monitor.Accuracy.Domain.Advisor;
using System;
using System.Collections.Generic;
using System.Text;

namespace Corporate.B2B.Rede.Monitor.Accuracy.Persistence.Repositories.Advisor
{
    public class AdvisorRepository : IAdvisorRepository
    {
        public IEnumerable<string> GetAllAdvisorCode()
        {
            throw new NotImplementedException();
        }
    }
}
