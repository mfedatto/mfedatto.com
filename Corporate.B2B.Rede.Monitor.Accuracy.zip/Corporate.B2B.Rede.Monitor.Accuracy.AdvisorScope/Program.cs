﻿using Castle.Windsor;
using Corporate.B2B.Rede.Monitor.Accuracy.Business.Queries.GetAllAdvisorCodeList;

namespace Corporate.B2B.Rede.Monitor.Accuracy.AdvisorScope
{
    static class Program
    {
        public static void Main(string[] args, WindsorContainer container = null)
        {
            var x = container.Resolve<GetAllAdvisorCodeListQuery>();
            var y = x.Execute(null);
            var z = y.AdvisorCodeList;
        }
    }
}
