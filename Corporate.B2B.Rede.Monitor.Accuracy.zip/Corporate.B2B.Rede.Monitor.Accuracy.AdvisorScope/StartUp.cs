﻿using Castle.Windsor;
using Corporate.B2B.Rede.Monitor.Accuracy.CrossCuting.DependencyInjection;
using System;

namespace Corporate.B2B.Rede.Monitor.Accuracy.AdvisorScope
{
    static class StartUp
    {
        static void Main(string[] args)
        {
            WindsorContainer container = new WindsorContainer();

            try
            {
                new CompositionRoot().ComposeApplication(container);

                Program.Main(args, container);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected exception thrown: {ex.Message}");
            }
            finally
            {
#pragma warning disable S2589 // Boolean expressions should not be gratuitous
                if (container != null)
#pragma warning restore S2589 // Boolean expressions should not be gratuitous
                {
                    container.Dispose();
                }
            }
        }
    }
}
