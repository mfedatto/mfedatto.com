﻿using Castle.Facilities.Logging;
using Castle.Services.Logging.Log4netIntegration;
using Castle.Windsor;

namespace Corporate.B2B.Rede.Monitor.Accuracy.CrossCuting.DependencyInjection
{
    public class CompositionRoot
    {
        public virtual void ComposeApplication(IWindsorContainer container)
        {
            container.AddFacility<LoggingFacility>(
                f => f.LogUsing<Log4netFactory>()
                    .WithLevel(Castle.Core.Logging.LoggerLevel.Debug));

            container.Install(
                new Installers.CrossCutting(),
                new Installers.Domain(),
                new Installers.Business(),
                new Installers.Persistence());
        }
    }
}
