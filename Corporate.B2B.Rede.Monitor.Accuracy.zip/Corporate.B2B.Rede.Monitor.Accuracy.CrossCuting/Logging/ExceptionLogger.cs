﻿using Castle.Core.Logging;
using Castle.DynamicProxy;
using System;

namespace Corporate.B2B.Rede.Monitor.Accuracy.CrossCuting.Logging
{
    public class ExceptionLogger : IInterceptor
    {
        ILogger Log { get; set; }

        public ExceptionLogger(ILogger log)
        {
            Log = log;
        }

        public void Intercept(IInvocation invocation)
        {
            try
            {
                invocation.Proceed();
            }
            catch (Exception ex)
            {
                Log.Error($"Method: '{invocation.Method.Name}' of class '{invocation.TargetType.Name}' failed", ex);
            }
        }
    }
}
