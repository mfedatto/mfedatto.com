﻿using Castle.Core.Logging;
using System;

namespace Corporate.B2B.Rede.Monitor.Accuracy.CrossCuting.Logging
{
    public class LoggingFactory : ILoggerFactory
    {
        public ILogger Create(Type type)
        {
            throw new NotImplementedException();
        }

        public ILogger Create(string name)
        {
            throw new NotImplementedException();
        }

        public ILogger Create(Type type, LoggerLevel level)
        {
            throw new NotImplementedException();
        }

        public ILogger Create(string name, LoggerLevel level)
        {
            throw new NotImplementedException();
        }
    }
}
