﻿using Castle.MicroKernel.Registration;
using Castle.MicroKernel.SubSystems.Configuration;
using Castle.Windsor;
using Corporate.B2B.Rede.Monitor.Accuracy.CrossCuting.Logging;

namespace Corporate.B2B.Rede.Monitor.Accuracy.CrossCuting.Installers
{
    public class CrossCutting : IWindsorInstaller
    {
        public void Install(IWindsorContainer container, IConfigurationStore store)
        {
            container.Register(Component.For<ExceptionLogger>());
        }
    }
}
