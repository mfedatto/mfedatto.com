﻿using Castle.MicroKernel.Registration;
using Castle.MicroKernel.SubSystems.Configuration;
using Castle.Windsor;
using Corporate.B2B.Rede.Monitor.Accuracy.CrossCuting.Logging;

namespace Corporate.B2B.Rede.Monitor.Accuracy.CrossCuting.Installers
{
    public class Domain : IWindsorInstaller
    {
        public void Install(IWindsorContainer container, IConfigurationStore store)
        {
            container.Register(Classes.FromAssemblyNamed("Corporate.B2B.Rede.Monitor.Accuracy.Domain")
                .Where(t => t.Name.EndsWith("Factory"))
                .WithServiceFirstInterface()
                .LifestyleSingleton()
                .Configure(c => c.Interceptors<ExceptionLogger>()));
        }
    }
}
