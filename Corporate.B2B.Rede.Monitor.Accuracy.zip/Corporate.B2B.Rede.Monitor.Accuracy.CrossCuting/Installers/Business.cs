﻿using Castle.MicroKernel.Registration;
using Castle.MicroKernel.SubSystems.Configuration;
using Castle.Windsor;
using Corporate.B2B.Rede.Monitor.Accuracy.CrossCuting.Logging;

namespace Corporate.B2B.Rede.Monitor.Accuracy.CrossCuting.Installers
{
    public class Business : IWindsorInstaller
    {
        public void Install(IWindsorContainer container, IConfigurationStore store)
        {
            container.Register(Classes.FromAssemblyNamed("Corporate.B2B.Rede.Monitor.Accuracy.Business")
                .Where(t => t.Name.EndsWith("Query"))
                .WithServiceFirstInterface()
                .LifestyleSingleton()
                .Configure(c => c.Interceptors<ExceptionLogger>()));
            container.Register(Classes.FromAssemblyNamed("Corporate.B2B.Rede.Monitor.Accuracy.Business")
                .Where(t => t.Name.EndsWith("Request"))
                .WithServiceFirstInterface()
                .LifestyleSingleton()
                .Configure(c => c.Interceptors<ExceptionLogger>()));
            container.Register(Classes.FromAssemblyNamed("Corporate.B2B.Rede.Monitor.Accuracy.Business")
                .Where(t => t.Name.EndsWith("Response"))
                .WithServiceFirstInterface()
                .LifestyleSingleton()
                .Configure(c => c.Interceptors<ExceptionLogger>()));
            container.Register(Classes.FromAssemblyNamed("Corporate.B2B.Rede.Monitor.Accuracy.Business")
                .Where(t => t.Name.EndsWith("Validator"))
                .WithServiceFirstInterface()
                .LifestyleSingleton()
                .Configure(c => c.Interceptors<ExceptionLogger>()));
        }
    }
}
