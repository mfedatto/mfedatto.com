﻿using Castle.MicroKernel.Facilities;
using Castle.MicroKernel.Registration;
using Corporate.B2B.Rede.Monitor.Accuracy.Domain.Advisor;
using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using NHibernate;
using NHibernate.Cfg;

namespace Corporate.B2B.Rede.Monitor.Accuracy.CrossCuting.Facilities
{
    public class OracleFacility : AbstractFacility
    {
        protected override void Init()
        {
            Configuration config = Fluently.Configure()
                .Database(SetupDatabase)
                .Mappings(m => m.FluentMappings.AddFromAssemblyOf<Advisor>())
                .ExposeConfiguration(ConfigurePersistance)
                .BuildConfiguration();

            Kernel.Register(
                Component.For<ISessionFactory>()
                    .UsingFactoryMethod(_ => config.BuildSessionFactory()),
                Component.For<ISession>()
                    .UsingFactoryMethod(k => k.Resolve<ISessionFactory>().OpenSession())
                );
        }

        public virtual IPersistenceConfigurer SetupDatabase()
        {
            return OracleClientConfiguration.Oracle9
                       .ConnectionString(c => c.Is(""));
        }

        public virtual void ConfigurePersistance(Configuration config)
        {

        }
    }
}
