﻿namespace Corporate.B2B.Rede.Monitor.Accuracy.Domain
{
    public interface IFactory<out TEntityInterface>
    {
        TEntityInterface Create();
    }
}
