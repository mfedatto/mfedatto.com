﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Corporate.B2B.Rede.Monitor.Accuracy.Domain.Advisor
{
    public interface IAdvisor
    {
        string AdvisorCode { get; set; }
        string AdvisorLogin { get; set; }
        string UserName { get; set; }
        string Name { get; set; }
        string[] MirroredAdvisorCodesList { get; set; }

    }
}
