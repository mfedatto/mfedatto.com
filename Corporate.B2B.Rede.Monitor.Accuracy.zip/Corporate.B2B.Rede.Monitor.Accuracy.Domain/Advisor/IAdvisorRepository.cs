﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Corporate.B2B.Rede.Monitor.Accuracy.Domain.Advisor
{
    public interface IAdvisorRepository
    {
        IEnumerable<string> GetAllAdvisorCode();
    }
}
