﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Corporate.B2B.Rede.Monitor.Accuracy.Domain.Advisor
{
    public class Advisor : IAdvisor
    {
        public string AdvisorCode { get; set; }
        public string AdvisorLogin { get; set; }
        public string UserName { get; set; }
        public string Name { get; set; }
        public string[] MirroredAdvisorCodesList { get; set; }
    }
}
