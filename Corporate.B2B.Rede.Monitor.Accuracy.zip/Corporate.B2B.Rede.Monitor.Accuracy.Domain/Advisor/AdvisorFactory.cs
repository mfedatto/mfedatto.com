﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Corporate.B2B.Rede.Monitor.Accuracy.Domain.Advisor
{
    public class AdvisorFactory : IFactory<IAdvisor>
    {
        public IAdvisor Create()
        {
            return new Advisor();
        }
    }
}
